﻿namespace Hahn.ApplicatonProcess.February2021.Domain.Enums
{
    public enum Department
    {
        HQ = 1,
        Store1 = 2,
        Store2 = 3,
        Store3 = 4,
        MaintenanceStation = 5
    }
}
