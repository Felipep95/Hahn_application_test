﻿using System;

namespace teste
{
    public class Class1
    {
    }
}
